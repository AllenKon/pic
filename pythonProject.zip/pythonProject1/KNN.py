import sklearn
import cv2
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier #加载sklearn自带的数据包
import serial
import pyautogui as ui
from ast import literal_eval
import matplotlib.pyplot as plt
from sklearn import datasets #加载sklearn自带的train_test_split函数
from sklearn.model_selection import train_test_split
from sklearn.datasets import load_iris
from sklearn.model_selection import cross_val_score
from sklearn.metrics import accuracy_score#加载数据包中自带的小数据集(鸢尾花数据集)
import time
import matplotlib.image as mpimg # mpimg 用于读取图片
import PySimpleGUI as sg
from PIL import Image

i=0
# 计数0,1,2
a=0
b=0
c=0
d=0
ser = serial.Serial('COM3', 9600)

data = pd.read_excel('./Total_all.xlsx')
demo1=b"0"#将0转换为ASCII码方便发送
demo2=b"1"#同理
demo3=b"2"#同理
x_axis = np.array(data['X']).reshape(-1,1)
y_axis = np.array(data['Y']).reshape(-1,1)
z_axis = np.array(data['Z']).reshape(-1,1)
label = np.array(data['class1']).reshape(-1)

eager = cv2.imread('./Group 33.jpg')
anger = cv2.imread('./Group 30.jpg')
happy = cv2.imread('./Group 32.jpg')
bored = cv2.imread('./Group 28.jpg')


pos = np.hstack((x_axis,y_axis,z_axis))

shuffle_indexes = np.random.permutation(pos.shape[0])

test_ratio = 0.2
test_size = int(pos.shape[0]*test_ratio)

test_indexes = shuffle_indexes[-test_size:]
train_indexes = shuffle_indexes[:-test_size]

X_train = pos[train_indexes]
y_train = label[train_indexes]

k_range = range(1, 101) # 设置循环次数
k_error = []

X_test = pos[test_indexes]
y_test = label[test_indexes]

X_train, X_test, y_train, y_test= train_test_split(pos, label, test_size=0.2, random_state=10)
KNN_classifier = KNeighborsClassifier(n_neighbors=6)
KNN_classifier.fit(X_train, y_train)
predict_y_test= KNN_classifier.predict(X_test)
#对测试的特征数组进行预测#针对train_test_split得到的y_test和预测出来的标签向量进行计算分类准确度

Classification_accuracy =accuracy_score(y_test, predict_y_test)
print(Classification_accuracy)
#针对train_test_split得到的测试用的特征数组和标签向量，直接计算其分类准确度(不用先计算出测试标签向量)

Classification_accuracy =KNN_classifier.score(X_test, y_test)
print(Classification_accuracy)

x=[]

predict_result=KNN_classifier.predict(X_test)

while True:
    datas = ser.readline()
    datas = datas.decode()
    if datas[0]!='[':
        continue #自检
    my_list = literal_eval(datas)

    for list in my_list:
        if list < 200:
            my_list[i]=0
            i=i+1
    i = 0

    print(my_list)
    #cv2.namedWindow("window_name", cv2.WINDOW_NORMAL)
    #cv2.setWindowProperty("window_name", cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)
    #cv2.imshow("window_name", eager)
    if my_list != [0,0,0]:
        #cv2.destroyAllWindows()
        while True:
            datas = ser.readline()
            datas = datas.decode()
            my_list = literal_eval(datas)
            for list in my_list:
                if list < 200:
                    my_list[i] = 0
                    i = i + 1
            i=0
            while i<=4:
                x.append(my_list)
                i=i+1
            i=0
            break
        if x == [[0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0]]:
            x=[]
            continue
        print(x)
        predict_result = KNN_classifier.predict(x)
        print(predict_result)
        x = []
        my_list=[0,0,0]
        while i<=4:
            if predict_result[i]==0:
                a=a+1
            elif predict_result[i]==1:
                b=b+1
            else:
                c=c+1
            i=i+1

        if a>=b and a>=c:
            print("Mock")
            cv2.namedWindow("window_name", cv2.WINDOW_NORMAL)
            cv2.setWindowProperty("window_name", cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)
            cv2.imshow("window_name", bored)
            ser.write(demo1)
            cv2.waitKey(5000)
            cv2.destroyAllWindows()

        elif b>=c and b>=a:
            print("Comfort")
            cv2.namedWindow("window_name", cv2.WINDOW_NORMAL)
            cv2.setWindowProperty("window_name", cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)
            cv2.imshow("window_name", happy)
            ser.write(demo2)
            cv2.waitKey(5000)
            cv2.destroyAllWindows()

        else:
            print("Anger")
            ser.write(demo3)
            cv2.namedWindow("window_name", cv2.WINDOW_NORMAL)
            cv2.setWindowProperty("window_name", cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)
            cv2.imshow("window_name", anger)
            cv2.waitKey(5000)
            cv2.destroyAllWindows()

        #time.sleep(5)
        Non = ser.read_all() #这行代码用来清除串口通信读取时缓冲区内数据，避免后续干扰
        #数据初始化
        predict_result = []
        a=0
        b=0
        c=0
        d=0
        i = 0
