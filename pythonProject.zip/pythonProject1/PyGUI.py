import PySimpleGUI as sg
from PIL import Image
filename='1.gif'
sg.theme('LightGreen')
gif_file = Image.open(filename)
# 窗体界面布局
size = gif_file.size

del gif_file
layout = [
        [sg.Image(key="-GIF-",filename='1.gif' ,background_color = "black")],
        [sg.Exit()],
    ]

# 窗体显示
window = sg.Window('PySimpleGUI Elements 测试', layout, background_color = "black").Finalize()
window.Maximize()
img = window["-GIF-"]
# 消息循环
while True:
    event, values = window.read(timeout = 10, timeout_key = "-TIMEOUT-")
    # print(event,values)
    if event == 'Exit' or event == sg.WIN_CLOSED:
        break
    img.UpdateAnimation(filename, time_between_frames=50)
    if event == '-GETFILE-':
        name = values['-GETFILE-']
        window['-TEXT1-'].update(name)
        window['-IMAGE-'].update(filename=name)

        window['-IMAGE-'].set_size(window['-IMAGE-'].get_size())

window.close()