import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits import mplot3d
# pd为pandas的别名，容易写
i=0
j=0
np_x=[]
np_y=[]
np_z=[]
'''

读取相对位置的excel,使用openpyxl引擎，
获取表名为表1 = Sheet1的内容
里面需要参数一般第一个为行号，第二个为列号


'''

data = pd.read_excel('./Total_all.xlsx')
'''

读取指定单元格，读取第一行，第一列，
即A2单元格（pandas读取表格默认不读取表头，即第一行）

'''
x_axis = data['X']
y_axis = data['Y']
z_axis = data['Z']
colors = data['class']


'''
while i <= 317:
    row_data0 = da.loc[[i]].values
    data = row_data0[0]
    x = data[0]
    y = data[1]
    z = data[2]
    np_x.append(x)
    np_y.append(y)
    np_z.append(z)
    i=i+1
x1 = np.array(np_x)#使用np.array进行转化
y1 = np.array(np_y)#使用np.array进行转化
z1 = np.array(np_z)#使用np.array进行转化
fig = plt.figure(figsize = (10, 7))
ax = plt.axes(projection ="3d")
# Creating a plot using the random datasets
ax.scatter(x1, y1, z1, color = "red",label='Angry')
plt.title("3D scatter plot")
# display the  plot
plt.show()
'''


# Creating figure
fig = plt.figure(figsize = (16, 12))
ax = plt.axes(projection ="3d")
# Add x, and y gridlines for the figure
ax.grid(b = True, color ='blue',linestyle ='-.', linewidth = 0.5,alpha = 0.3)
# Creating the color map for the plot
my_cmap = plt.get_cmap('hsv')
# Creating the 3D plot
sctt = ax.scatter3D(x_axis, y_axis, z_axis,alpha = 0.8,c = colors,cmap = my_cmap,marker ='^')
plt.title("Patting Plot")
ax.set_xlabel('RTS_1', fontweight ='bold')
ax.set_ylabel('RTS_2', fontweight ='bold')
ax.set_zlabel('RTS_3', fontweight ='bold')
# display the plot
plt.show()