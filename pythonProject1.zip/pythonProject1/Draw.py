import numpy as np
import serial
from ast import literal_eval
import pyqtgraph as pg
from PyQt5 import QtWidgets, QtCore
import asyncio

# 定义全局变量
data_available = asyncio.Event()
shared_data = np.zeros(3)

app = QtWidgets.QApplication([])

win = pg.GraphicsLayoutWidget(show=True)
win.setWindowTitle('Multiple Curve Plot')

# 创建三个绘图区域
plot1 = win.addPlot(title='Curve 1')
plot2 = win.addPlot(title='Curve 2')
plot3 = win.addPlot(title='Curve 3')


def update1():
    global shared_data, ptr1
    plot1.setData(shared_data[0])
    plot2.setData(shared_data[1])
    plot3.setData(shared_data[2])


# 定义 Qt 事件循环定时器
timer = QtCore.QTimer()
timer.timeout.connect(update1)
timer.start(50)  # 设置定时器间隔，单位是毫秒


async def clear_serial_buffer(ser):
    # 清空串口输入缓冲区
    ser.flushInput()


async def serial_reader(serial_port):
    # 异步IO串口通信，改变全局变量
    global shared_data, data_available
    with serial.Serial(serial_port, baudrate=115200, timeout=0.1) as ser:
        while True:
            await clear_serial_buffer(ser)  # 清空串口缓冲区
            data = ser.readline().decode('utf-8').strip()  # 从串口读取一行数据
            shared_data = np.array(literal_eval(data))  # 将解析后的数据存入全局变量
            print(shared_data)
            data_available.set()  # 通知主线程有新的数据可用
            await asyncio.sleep(0.01)  # 根据需要调整，通过 sleep 控制事件循环的频率


# async def main(serial_port):
#     # 主协程，启动异步IO串口通信和主线程的图表更新
#     asyncio.create_task(serial_reader(serial_port))
#     while True:
#         await asyncio.sleep(0.1)  # 根据需要调整，通过 sleep 控制事件循环的频率
#         update_graph()

if __name__ == "__main__":
    # 将信号槽连接到更新函数
    # signal_obj.update_signal.connect(barGraph.setOpts)

    # 启动主线程中的协程
    serial_port = 'COM12'  # 根据实际情况调整串口
    loop = asyncio.get_event_loop()
    loop.run_until_complete(serial_reader(serial_port))
