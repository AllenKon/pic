import sklearn
import cv2
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier #加载sklearn自带的数据包
import serial
import pyautogui as ui
from ast import literal_eval
import matplotlib.pyplot as plt
from sklearn import datasets #加载sklearn自带的train_test_split函数
from sklearn.model_selection import train_test_split
from sklearn.datasets import load_iris
from sklearn.model_selection import cross_val_score
from sklearn.metrics import accuracy_score#加载数据包中自带的小数据集(鸢尾花数据集)
import time
import matplotlib.image as mpimg # mpimg 用于读取图片

import PySimpleGUI as sg
from PIL import Image

i=0
j=0
# 计数0,1,2
a=0
b=0
c=0
d=0
ser = serial.Serial('COM3', 9600)

Normal = "./Normal.gif"
NormalN = "./NormalN.gif"
Boredom = "./Boredom.gif"
Anger = "./Anger.gif"
AngerN = "./AngerN.gif"
Happiness = "./Happiness.gif"
HappinessN = "./HappinessN.gif"
N_A = "./Normal-Anger.gif"
N_B = "./Normal-Bored.gif"
N_H = "./Normal-Happiness.gif"
BoredomN = "./BoredomN.gif"
gif_file = Image.open(Normal)
i=0
size = gif_file.size
del gif_file

layout = [
        [sg.Image(Normal, key = "-GIF-", size = size, background_color = "black")]
]
window = sg.Window("GIF", layout = layout, finalize = True)
window.maximize()

# find Image element so that we can use it in the event loop
img = window["-GIF-"]


data = pd.read_excel('./Total_all.xlsx')
demo1=b"0"#将0转换为ASCII码方便发送
demo2=b"1"#同理
demo3=b"2"#同理

x_axis = np.array(data['X']).reshape(-1,1)
y_axis = np.array(data['Y']).reshape(-1,1)
z_axis = np.array(data['Z']).reshape(-1,1)
label = np.array(data['class1']).reshape(-1)

eager = cv2.imread('./Group 33.jpg')
anger = cv2.imread('./Group 30.jpg')
happy = cv2.imread('./Group 32.jpg')
bored = cv2.imread('./Group 28.jpg')

pos = np.hstack((x_axis,y_axis,z_axis))

shuffle_indexes = np.random.permutation(pos.shape[0])

test_ratio = 0.2
test_size = int(pos.shape[0]*test_ratio)

test_indexes = shuffle_indexes[-test_size:]
train_indexes = shuffle_indexes[:-test_size]

X_train = pos[train_indexes]
y_train = label[train_indexes]

k_range = range(1, 101) # 设置循环次数
k_error = []

X_test = pos[test_indexes]
y_test = label[test_indexes]

X_train, X_test, y_train, y_test= train_test_split(pos, label, test_size=0.2, random_state=10)
KNN_classifier = KNeighborsClassifier(n_neighbors=6)
KNN_classifier.fit(X_train, y_train)
predict_y_test= KNN_classifier.predict(X_test)
#对测试的特征数组进行预测#针对train_test_split得到的y_test和预测出来的标签向量进行计算分类准确度

Classification_accuracy =accuracy_score(y_test, predict_y_test)
print(Classification_accuracy)
#针对train_test_split得到的测试用的特征数组和标签向量，直接计算其分类准确度(不用先计算出测试标签向量)

Classification_accuracy =KNN_classifier.score(X_test, y_test)
print(Classification_accuracy)

x=[]

predict_result=KNN_classifier.predict(X_test)

while True:
    datas = ser.readline()
    datas = datas.decode()
    if datas[0]!='[':
        continue #自检
    my_list = literal_eval(datas)

    for list in my_list:
        if list < 200:
            my_list[i]=0
            i=i+1
    i = 0
    print(my_list)

    if j <= 40:
        event, values = window.read(timeout=10, timeout_key="-TIMEOUT-")
        if event in (sg.WIN_CLOSED, "Quit", "Cancel"):
            break
        img.UpdateAnimation(Normal, time_between_frames=20)
    if j <120 and j>40:
        event, values = window.read(timeout=10, timeout_key="-TIMEOUT-")
        if event in (sg.WIN_CLOSED, "Quit", "Cancel"):
            break
        img.UpdateAnimation(NormalN, time_between_frames=50)
    if j == 200:
        j = 0
    j = j + 1

    if my_list != [0,0,0]:
        while True:
            datas = ser.readline()
            datas = datas.decode()
            my_list = literal_eval(datas)
            for list in my_list:
                if list < 200:
                    my_list[i] = 0
                    i = i + 1
            i=0
            while i<=4:
                x.append(my_list)
                i=i+1
            i=0
            break
        if x == [[0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0]]:
            x=[]
            continue
        print(x)
        predict_result = KNN_classifier.predict(x)
        print(predict_result)
        x = []
        my_list=[0,0,0]
        while i<=4:
            if predict_result[i]==0:
                a=a+1
            elif predict_result[i]==1:
                b=b+1
            else:
                c=c+1
            i=i+1
        i = 0
        j = 0
        if a>=b and a>=c:
            print("Boredom")
            ser.write(demo1)
            while i < 200:
                if j == 0:
                    if i < 30:
                        event, values = window.read(timeout=10, timeout_key="-TIMEOUT-")
                        if event in (sg.WIN_CLOSED, "Quit", "Cancel"):
                            break
                        img.UpdateAnimation(N_B, time_between_frames=30)
                        i = i + 1
                    if i > 40 and i <= 85:
                        event, values = window.read(timeout=10, timeout_key="-TIMEOUT-")
                        if event in (sg.WIN_CLOSED, "Quit", "Cancel"):
                            break
                        img.UpdateAnimation(Boredom, time_between_frames=20)
                    if i > 85:
                        event, values = window.read(timeout=10, timeout_key="-TIMEOUT-")
                        if event in (sg.WIN_CLOSED, "Quit", "Cancel"):
                            break
                        img.UpdateAnimation(BoredomN, time_between_frames=30)
                    if i == 199:
                        i = 0
                        j = 1
                        continue

                if j == 1:
                    if i <= 45:
                        event, values = window.read(timeout=10, timeout_key="-TIMEOUT-")
                        if event in (sg.WIN_CLOSED, "Quit", "Cancel"):
                            break
                        img.UpdateAnimation(Boredom, time_between_frames=30)
                    if i < 114 and i>45:
                        event, values = window.read(timeout=10, timeout_key="-TIMEOUT-")
                        if event in (sg.WIN_CLOSED, "Quit", "Cancel"):
                            break
                        img.UpdateAnimation(BoredomN, time_between_frames=30)
                    if i == 114:
                        break
                i = i + 1


        elif b>=c and b>=a:
            print("Happiness")
            ser.write(demo2)
            while i < 200:
                if j == 0:
                    if i < 30:
                        event, values = window.read(timeout=10, timeout_key="-TIMEOUT-")
                        if event in (sg.WIN_CLOSED, "Quit", "Cancel"):
                            break
                        img.UpdateAnimation(N_H, time_between_frames=30)
                        i = i + 1
                    if i > 40 and i <= 85:
                        event, values = window.read(timeout=10, timeout_key="-TIMEOUT-")
                        if event in (sg.WIN_CLOSED, "Quit", "Cancel"):
                            break
                        img.UpdateAnimation(Happiness, time_between_frames=20)
                    if i > 85:
                        event, values = window.read(timeout=10, timeout_key="-TIMEOUT-")
                        if event in (sg.WIN_CLOSED, "Quit", "Cancel"):
                            break
                        img.UpdateAnimation(HappinessN, time_between_frames=30)
                    if i == 199:
                        i = 0
                        j = 1
                        continue

                if j == 1:
                    if i <= 45:
                        event, values = window.read(timeout=10, timeout_key="-TIMEOUT-")
                        if event in (sg.WIN_CLOSED, "Quit", "Cancel"):
                            break
                        img.UpdateAnimation(Happiness, time_between_frames=30)
                    if i < 114 and i > 45:
                        event, values = window.read(timeout=10, timeout_key="-TIMEOUT-")
                        if event in (sg.WIN_CLOSED, "Quit", "Cancel"):
                            break
                        img.UpdateAnimation(HappinessN, time_between_frames=30)
                    if i == 114:
                        break
                i = i + 1
            #cv2.waitKey(5000)
            #cv2.destroyAllWindows()

        else:
            print("Anger")
            ser.write(demo3)
            while i < 200:
                print(i)
                if j == 0:
                    if i < 28:
                        event, values = window.read(timeout=10, timeout_key="-TIMEOUT-")
                        if event in (sg.WIN_CLOSED, "Quit", "Cancel"):
                            break
                        img.UpdateAnimation(N_A, time_between_frames=30)
                        i = i + 1
                    if i > 40 and i <= 82:
                        event, values = window.read(timeout=10, timeout_key="-TIMEOUT-")
                        if event in (sg.WIN_CLOSED, "Quit", "Cancel"):
                            break
                        img.UpdateAnimation(Anger, time_between_frames=20)
                    if i > 82:
                        event, values = window.read(timeout=10, timeout_key="-TIMEOUT-")
                        if event in (sg.WIN_CLOSED, "Quit", "Cancel"):
                            break
                        img.UpdateAnimation(AngerN, time_between_frames=30)
                    if i == 199:
                        i = 0
                        j = 1
                        continue

                if j == 1:
                    if i <= 42:
                        event, values = window.read(timeout=10, timeout_key="-TIMEOUT-")
                        if event in (sg.WIN_CLOSED, "Quit", "Cancel"):
                            break
                        img.UpdateAnimation(Anger, time_between_frames=20)
                    if i < 114 and i > 42:
                        event, values = window.read(timeout=10, timeout_key="-TIMEOUT-")
                        if event in (sg.WIN_CLOSED, "Quit", "Cancel"):
                            break
                        img.UpdateAnimation(AngerN, time_between_frames=30)
                    if i == 114:
                        break
                i = i + 1

        #time.sleep(5)
        Non = ser.read_all() #这行代码用来清除串口通信读取时缓冲区内数据，避免后续干扰
        #数据初始化
        predict_result = []
        a = 0
        b = 0
        c = 0
        d = 0
        i = 0

window.close()
del window