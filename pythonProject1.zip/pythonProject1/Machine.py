import threading
import serial
import numpy as np
from ast import literal_eval
import PySimpleGUI as sg
import statistics

# 初始化共享数据
shared_data = np.zeros((3, 15))

# 定义GUI布局和窗口
# gifs = ['Normal.gif', 'Boredom.gif', 'Happiness.gif', 'Anger.gif']
# gifs_sequences = {
#     'S0': ['Normal.gif', 'NormalN.gif'],
#     'S1': ['Normal-Bored.gif', 'Boredom.gif', 'BoredomN.gif'],
#     'S2': ['Normal-Happiness.gif', 'Happiness.gif', 'HappinessN.gif'],
#     'S3': ['Anger1.gif', 'Anger2.gif', 'Anger3.gif'],
# }

gifs_sequences = {
    'S0': [('Normal.gif', 44), ('NormalN.gif', 9)],
    'S1': [('Boredom.gif', 46), ('Boredom.gif', 1), ('BoredomN.gif', 1000)],
    'S2': [('Normal-Happiness.gif', 44), ('Happiness.gif', 5), ('HappinessN.gif', 200)],
    'S3': [('Normal-Anger.gif', 44), ('Anger.gif', 200), ('AngerN.gif', 200)],
}


layout = [[sg.Image(key='-GIF-')]]
window = sg.Window('Window with GIFs', layout, finalize=True)

# 当前播放GIF的索引和计数器
current_sequence = []
current_gif_index = 0
frame_count = 0



class SerialPort:
    def __init__(self, read_port, write_port, baudrate):
        self.read_ser = serial.Serial(read_port, baudrate, timeout=1)
        self.write_ser = serial.Serial(write_port, baudrate, timeout=1) # 新增的写入串口
        self.read_thread = threading.Thread(target=self.read_from_port)
        self.alive = False
        self.data_list = []  # 用于存储收集到的数据

    def start(self):
        self.alive = True
        self.read_thread.start()

    def stop(self):
        self.alive = False
        self.read_thread.join()

    def read_from_port(self):
        global current_sequence, sequence_index, frame_count
        threshold1 = 10
        threshold2 = 40
        threshold3 = 60
        while self.alive:
            try:
                data = self.read_ser.readline().decode('utf-8').strip()  # 修改为从读取串口读数据
                data = literal_eval(data)
                if data:
                    self.data_list.append(statistics.mean(data))
                    if len(self.data_list) == 15:
                        average = sum(self.data_list) / len(self.data_list)
                        print(f"Average: {average}")  # 打印平均数
                        # 实际应用中需要根据平均数来决定设置current_gif_index的逻辑
                        if average < threshold1:
                            current_sequence = gifs_sequences['S0']
                            # print("S0")
                        elif threshold1 <= average < threshold2:
                            current_sequence = gifs_sequences['S1']
                            self.write_ser.write(b"S1\n")
                            # print("S1")
                        elif threshold2 <= average < threshold3:
                            current_sequence = gifs_sequences['S2']
                            self.write_ser.write(b"S2\n")
                            # print("S2")
                        else:
                            current_sequence = gifs_sequences['S3']
                            self.write_ser.write(b"S3\n")
                            # print("S3")
                        sequence_index = 0
                        frame_count = 0
                        self.data_list.clear()  # 清空列表，为下一轮收集准备
            except ValueError as e:
                print(f"Error parsing data: {e}")




# if __name__ == '__main__':
#     serial_port = SerialPort('COM12', 'COM4', 115200)
#     try:
#         serial_port.start()
#         # current_sequence = gifs_sequences['S0']
#         # sequence_index = 0  # 从合集中的第一个GIF开始播放
#         # gif, duration = current_sequence[sequence_index]
#         # window['-GIF-'].update(filename=gif)  # 初始GIF
#         while True:
#             event, values = window.read(timeout=10)
#             if event in (sg.WIN_CLOSED, 'Exit'):
#                 break
#             if current_sequence and sequence_index < len(current_sequence):
#                 gif, duration = current_sequence[sequence_index]
#                 if frame_count < duration:
#                     window['-GIF-'].UpdateAnimation(gif, time_between_frames=40)
#                     frame_count += 1
#                 else:
#                     frame_count = 0
#                     sequence_index += 1
#                     if sequence_index < len(current_sequence):
#                         # 更新为下一个GIF
#                         gif, duration = current_sequence[sequence_index]
#                         window['-GIF-'].UpdateAnimation(gif, time_between_frames=40)
#                     else:
#                         # 当前情绪的GIF合集播放完毕
#                         current_sequence = []
#                         sequence_index = 0
#                 print(gif + ' ' + str(frame_count))
#                 print(current_sequence)
#
#     except KeyboardInterrupt:
#         print("Stopping program")
#     finally:
#         serial_port.stop()
#         window.close()


# ...省略其他代码...

if __name__ == '__main__':
    serial_port = SerialPort('COM12', 'COM4', 115200)
    try:
        serial_port.start()
        while True:
            event, values = window.read(timeout=10)
            if event in (sg.WIN_CLOSED, 'Exit'):
                break
            if current_sequence and sequence_index < len(current_sequence):
                gif, duration = current_sequence[sequence_index]
                if frame_count < duration:
                    if frame_count == 0:  # 在这里检查是否是GIF序列中新GIF的第一帧
                        window['-GIF-'].update(filename=gif)  # 为新GIF设置文件名
                        window['-GIF-'].UpdateAnimation(gif, time_between_frames=40)  # 重新开始动画播放
                    else:
                        window['-GIF-'].UpdateAnimation(gif, time_between_frames=40)  # 继续当前GIF的动画播放
                    frame_count += 1
                else:
                    frame_count = 0  # 重置帧计数
                    sequence_index += 1  # 移动到序列中的下一个GIF
                    if sequence_index < len(current_sequence):
                        gif, duration = current_sequence[sequence_index]
                        # 对于新的GIF，frame_count 已经在上面重置为0，这里不需要再次更新window['-GIF-']的filename
                    else:
                        # 当前情绪的GIF合集播放完毕
                        current_sequence = []
                        sequence_index = 0
                print(gif + ' ' + str(frame_count))
                print(current_sequence)
    except KeyboardInterrupt:
        print("Stopping program")
    finally:
        serial_port.stop()
        window.close()
