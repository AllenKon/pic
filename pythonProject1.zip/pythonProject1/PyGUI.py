import PySimpleGUI as sg

from PIL import Image

filename = "./1.gif"
filename1 = "./2.gif"
gif_file = Image.open(filename)
i=0
size = gif_file.size

del gif_file

layout = [
        [sg.Image(filename, key = "-GIF-", size = size, background_color = "black")]
]


window = sg.Window("GIF", layout = layout, finalize = True)

# find Image element so that we can use it in the event loop
img = window["-GIF-"]

# default paused
play = True

while True:
    event, values = window.read(timeout = 10, timeout_key = "-TIMEOUT-")

    # way to quit
    if event in (sg.WIN_CLOSED, "Quit", "Cancel"):
        break
    if i<=200:
        img.UpdateAnimation(filename, time_between_frames=50)
    i=i+1
    print(i)
    if i>200:
        img.UpdateAnimation(filename1, time_between_frames=50)
    if i == 400:
        i = 0


window.close()
del window