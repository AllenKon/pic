import serial
from ast import literal_eval
import openpyxl
import xlwt
import xlrd

vars = " "
num = {}
i=0
j=0
k=0
d=0
wb = xlwt.Workbook()
# 添加一个表
ws = wb.add_sheet('test')
nums=[]
x=[]
ser = serial.Serial('COM3', 9600)

while True:
    datas = ser.readline()
    datas = datas.decode()
    my_list = literal_eval(datas)
    while d<1:
        print("Ready!")
        d=1
    if my_list != [0, 0, 0]:
        while True:
            datas = ser.readline()
            datas = datas.decode()
            my_list = literal_eval(datas)


            if my_list[0] <= 210:
                my_list[0] = 0

            i = 0
            while i <= 4:
                x.append(my_list)
                i = i + 1
            i = 0
            break
        if x == [[0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0]]:
            x = []
            continue
        for xs in x[0]:
            ws.write(k, j, xs)
            j = j + 1
        k = k + 1
        j = 0
        wb.save('Boredom_M3.xls')
    else:
        x=[]
        continue
    print(x[0])
    x=[]



