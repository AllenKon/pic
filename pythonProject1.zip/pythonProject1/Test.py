import sklearn
import cv2
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier #加载sklearn自带的数据包
import serial
import pyautogui as ui
from ast import literal_eval
import matplotlib.pyplot as plt
from sklearn import datasets #加载sklearn自带的train_test_split函数
from sklearn.model_selection import train_test_split
from sklearn.datasets import load_iris
from sklearn.model_selection import cross_val_score
from sklearn.metrics import accuracy_score#加载数据包中自带的小数据集(鸢尾花数据集)
import time
import matplotlib.image as mpimg # mpimg 用于读取图片

import PySimpleGUI as sg
from PIL import Image

i=0
j=0
# 计数0,1,2
a=0
b=0
c=0
d=0


Normal = "./Normal.gif"
NormalN = "./NormalN.gif"
Boredom = "./Boredom.gif"
Anger = "./Anger.gif"
AngerN = "./AngerN.gif"
Happiness = "./Happiness.gif"
HappinessN = "./HappinessN.gif"
N_A = "./Normal-Anger.gif"
N_B = "./Normal-Bored.gif"
N_H = "./Normal-Happiness.gif"
BoredomN = "./BoredomN.gif"
gif_file = Image.open(Normal)
i=0
size = gif_file.size
del gif_file

layout = [
        [sg.Image(Normal, key = "-GIF-", size = size, background_color = "black")]
]
window = sg.Window("GIF", layout = layout, resizable= True, finalize = True)
window.maximize()

# find Image element so that we can use it in the event loop
img = window["-GIF-"]
while i < 200:
    print(i)
    if j == 0:
        if i < 28:
            event, values = window.read(timeout=10, timeout_key="-TIMEOUT-")
            if event in (sg.WIN_CLOSED, "Quit", "Cancel"):
                break
            img.UpdateAnimation(N_B, time_between_frames=30)
            i = i + 1
        if i > 40 and i <= 82:
            event, values = window.read(timeout=10, timeout_key="-TIMEOUT-")
            if event in (sg.WIN_CLOSED, "Quit", "Cancel"):
                break
            img.UpdateAnimation(Boredom, time_between_frames=20)
        if i > 82:
            event, values = window.read(timeout=10, timeout_key="-TIMEOUT-")
            if event in (sg.WIN_CLOSED, "Quit", "Cancel"):
                break
            img.UpdateAnimation(BoredomN, time_between_frames=30)
        if i == 199:
            i = 0
            j = 1
            continue

    if j == 1:
        if i <= 42:
            event, values = window.read(timeout=10, timeout_key="-TIMEOUT-")
            if event in (sg.WIN_CLOSED, "Quit", "Cancel"):
                break
            img.UpdateAnimation(Boredom, time_between_frames=20)
        if i < 114 and i > 42:
            event, values = window.read(timeout=10, timeout_key="-TIMEOUT-")
            if event in (sg.WIN_CLOSED, "Quit", "Cancel"):
                break
            img.UpdateAnimation(BoredomN, time_between_frames=30)
        if i == 114:
            break
    i = i + 1
i=0
while True:
    if i <= 42:
        event, values = window.read(timeout=10, timeout_key="-TIMEOUT-")
        if event in (sg.WIN_CLOSED, "Quit", "Cancel"):
            break
        img.UpdateAnimation(Boredom, time_between_frames=20)
    if i < 1000 and i > 42:
        event, values = window.read(timeout=10, timeout_key="-TIMEOUT-")
        if event in (sg.WIN_CLOSED, "Quit", "Cancel"):
            break
        img.UpdateAnimation(BoredomN, time_between_frames=30)
    if i==1000:
        i=0
    i=i+1


