import numpy as np
import serial
from ast import literal_eval
import pyqtgraph as pg
from PyQt5 import QtWidgets, QtCore
import asyncio
import threading
import time

import sklearn
import cv2
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier #加载sklearn自带的数据包
import serial
import pyautogui as ui
from ast import literal_eval
import matplotlib.pyplot as plt
from sklearn import datasets #加载sklearn自带的train_test_split函数
from sklearn.model_selection import train_test_split
from sklearn.datasets import load_iris
from sklearn.model_selection import cross_val_score
from sklearn.metrics import accuracy_score#加载数据包中自带的小数据集(鸢尾花数据集)
import time
import matplotlib.image as mpimg # mpimg 用于读取图片

import PySimpleGUI as sg
from PIL import Image

Normal = "./Normal.gif"
NormalN = "./NormalN.gif"
Boredom = "./Boredom.gif"
Anger = "./Anger.gif"
AngerN = "./AngerN.gif"
Happiness = "./Happiness.gif"
HappinessN = "./HappinessN.gif"
N_A = "./Normal-Anger.gif"
N_B = "./Normal-Bored.gif"
N_H = "./Normal-Happiness.gif"
BoredomN = "./BoredomN.gif"
# gif_file = Image.open(Normal)

# size = gif_file.size
# del gif_file
#
# layout = [
#         [sg.Image(Normal, key = "-GIF-", size = size, background_color = "black")]
# ]
# window = sg.Window("GIF", layout = layout, finalize = True)
# window.maximize()
#
# img = window["-GIF-"]

demo1=b"0"#将0转换为ASCII码方便发送
demo2=b"1"#同理
demo3=b"2"#同理


# 定义全局变量
data_available = asyncio.Event()
shared_data = np.zeros((3, 10))  # 初始化一个3行100列的数组，表示三个曲线的初始数据
time_axis = np.arange(10)  # 时间轴，用于 x 轴


app = QtWidgets.QApplication([])

win = pg.GraphicsLayoutWidget(show=True)
win.setWindowTitle('Multiple Forces Plot')

# 创建三个绘图区域
plot1 = win.addPlot(title='Force 1')
plot2 = win.addPlot(title='Force 2')
plot3 = win.addPlot(title='Force 3')
plot = win.addPlot(title='Multiple Forces')

# 初始化三条曲线
curve1 = plot1.plot(pen='r')
curve2 = plot2.plot(pen='g')
curve3 = plot3.plot(pen='b')
curve_1 = plot.plot(pen='r')
curve_2 = plot.plot(pen='g')
curve_3 = plot.plot(pen='b')


def linear_mapping(new_data, x_min1, x_max1, x_min2, x_max2, x_min3, x_max3, y_min, y_max):
    # 将 x 限制在 [x_min, x_max] 范围内
    new_data[0] = max(min(new_data[0], x_max1), x_min1)
    new_data[1] = max(min(new_data[1], x_max2), x_min2)
    new_data[2] = max(min(new_data[2], x_max3), x_min3)
    # 计算缩放因子和平移因子
    a1 = (y_max - y_min) / (x_max1 - x_min1)
    b1 = y_min - a1 * x_min1

    a2 = (y_max - y_min) / (x_max2 - x_min2)
    b2 = y_min - a2 * x_min2

    a3 = (y_max - y_min) / (x_max3 - x_min3)
    b3 = y_min - a3 * x_min3
    # 应用线性映射
    new_data[0] = 100 - a1 * new_data[0] - b1
    new_data[1] = 100 - a2 * new_data[1] - b2
    new_data[2] = 100 - a3 * new_data[2] - b3
    return new_data




def update_graph():
    global shared_data, time_axis
    curve1.setData(time_axis, shared_data[0])
    curve2.setData(time_axis, shared_data[1])
    curve3.setData(time_axis, shared_data[2])
    curve_1.setData(time_axis, shared_data[0])
    curve_2.setData(time_axis, shared_data[1])
    curve_3.setData(time_axis, shared_data[2])


def clear_serial_buffer(ser):
    # 清空串口输入缓冲区
    ser.flushInput()


def serial_reader(serial_port):
    # 串口通信任务，放在子线程中执行
    global shared_data, time_axis, data_available, i
    count = 0
    with serial.Serial(serial_port, baudrate=115200, timeout=0.1) as ser:
        while True:
            clear_serial_buffer(ser)  # 清空串口缓冲区
            data = ser.readline().decode('utf-8').strip()  # 从串口读取一行数据
            new_data = np.array(literal_eval(data))
            new_data = linear_mapping(new_data, 1619, 2510, 1780, 2650, 1945, 2700, 0, 100)
            # 将新数据添加到数组的末尾
            shared_data[:, :-1] = shared_data[:, 1:]
            shared_data[:, -1] = new_data
            data_available.set()  # 通知主线程有新的数据可用
            time.sleep(0.01)  # 根据需要调整，通过 sleep 控制事件循环的频率


# 启动串口读取的子线程
serial_thread = threading.Thread(target=serial_reader, args=('COM12',))
serial_thread.start()

# 定义 Qt 事件循环定时器
timer = QtCore.QTimer()
timer.timeout.connect(update_graph)
timer.start(50)  # 设置定时器间隔，单位是毫秒

# 运行 Qt 事件循环
QtWidgets.QApplication.instance().exec_()
