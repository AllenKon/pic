import PySimpleGUI as sg
import time

# 假设你的 GIF 被分解成了多个文件，文件名依次为 frame_1.png, frame_2.png, ..., frame_N.png
frame_files = ['Normal.gif', 'Normal-Anger.gif', 'Anger.gif']  # 例子中的帧文件名
frame_index = 0  # 当前显示的帧

layout = [
    [sg.Image(key="-IMAGE-")],  # 使用 Image 元素显示 GIF 的一帧
]

window = sg.Window("GIF Animation", layout)

while True:
    event, values = window.read(timeout=100)  # 短暂的超时值允许定期更新图像
    if event == sg.WIN_CLOSED or event == "Exit":
        break

    # 更新图像显示下一帧
    window["-IMAGE-"].update(filename=frame_files[frame_index])
    frame_index = (frame_index + 1) % len(frame_files)  # 循环帧索引

window.close()
